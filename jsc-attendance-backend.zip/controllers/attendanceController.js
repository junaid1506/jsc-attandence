const Attendance = require('../models/Attendance');

const recordEntry = async (req, res) => {
  try {
    const { id: userId } = req.user;
    const entryTime = new Date();

    // Check if already has entry today
    const today = entryTime.toISOString().split('T')[0];
    const todayEntries = await Attendance.getUserEntries(userId, today);
    
    if (todayEntries.length > 0) {
      return res.status(400).json({ message: 'Entry already recorded for today' });
    }

    const entryId = await Attendance.createEntry(userId, entryTime);
    res.status(201).json({ message: 'Entry recorded', entryId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

const recordExit = async (req, res) => {
  try {
    const { id: userId } = req.user;
    const exitTime = new Date();
    const today = exitTime.toISOString().split('T')[0];

    // Get today's entry
    const todayEntries = await Attendance.getUserEntries(userId, today);
    
    if (todayEntries.length === 0) {
      return res.status(400).json({ message: 'No entry recorded for today' });
    }

    const entry = todayEntries[0];
    if (entry.exit_time) {
      return res.status(400).json({ message: 'Exit already recorded for today' });
    }

    const affectedRows = await Attendance.updateExit(entry.id, exitTime);
    if (affectedRows === 0) {
      return res.status(400).json({ message: 'Failed to record exit' });
    }

    res.json({ message: 'Exit recorded' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

const getUserEntries = async (req, res) => {
  try {
    const { id: userId } = req.user;
    const entries = await Attendance.getUserEntries(userId);
    res.json(entries);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

const getAllEntries = async (req, res) => {
  try {
    const filters = {
      userId: req.query.userId,
      date: req.query.date,
      fromDate: req.query.fromDate,
      toDate: req.query.toDate
    };
    
    const entries = await Attendance.getAllEntries(filters);
    res.json(entries);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

const getDashboardStats = async (req, res) => {
  try {
    const stats = await Attendance.getTodayStats();
    res.json(stats);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  recordEntry,
  recordExit,
  getUserEntries,
  getAllEntries,
  getDashboardStats
};