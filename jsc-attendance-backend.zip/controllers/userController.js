const User = require('../models/User');

const getAllEmployees = async (req, res) => {
  try {
    const employees = await User.getAll();
    res.json(employees);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { getAllEmployees };