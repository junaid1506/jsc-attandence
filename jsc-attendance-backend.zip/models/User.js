const db = require('../config/db');

class User {
  static async findByUsername(username) {
    const [rows] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT id, username, role, full_name FROM users WHERE id = ?', [id]);
    return rows[0];
  }

  static async create(user) {
    const { username, password, role, full_name } = user;
    const [result] = await db.query(
      'INSERT INTO users (username, password, role, full_name) VALUES (?, ?, ?, ?)',
      [username, password, role, full_name]
    );
    return result.insertId;
  }

  static async getAll() {
    const [rows] = await db.query('SELECT id, username, role, full_name FROM users WHERE role = "employee"');
    return rows;
  }
}

module.exports = User;