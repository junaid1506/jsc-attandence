const db = require('../config/db');

class Attendance {
  static async createEntry(userId, entryTime) {
    const [result] = await db.query(
      'INSERT INTO attendance (user_id, entry_time) VALUES (?, ?)',
      [userId, entryTime]
    );
    return result.insertId;
  }

  static async updateExit(attendanceId, exitTime) {
    const [result] = await db.query(
      'UPDATE attendance SET exit_time = ? WHERE id = ?',
      [exitTime, attendanceId]
    );
    return result.affectedRows;
  }

  static async getUserEntries(userId, date) {
    let query = 'SELECT * FROM attendance WHERE user_id = ?';
    const params = [userId];

    if (date) {
      query += ' AND DATE(entry_time) = ?';
      params.push(date);
    }

    query += ' ORDER BY entry_time DESC';

    const [rows] = await db.query(query, params);
    return rows;
  }

  static async getAllEntries(filters = {}) {
    let query = `
      SELECT a.*, u.full_name 
      FROM attendance a
      JOIN users u ON a.user_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (filters.userId) {
      query += ' AND a.user_id = ?';
      params.push(filters.userId);
    }

    if (filters.date) {
      query += ' AND DATE(a.entry_time) = ?';
      params.push(filters.date);
    }

    if (filters.fromDate && filters.toDate) {
      query += ' AND DATE(a.entry_time) BETWEEN ? AND ?';
      params.push(filters.fromDate, filters.toDate);
    }

    query += ' ORDER BY a.entry_time DESC';

    const [rows] = await db.query(query, params);
    return rows;
  }

  static async getTodayStats() {
    const today = new Date().toISOString().split('T')[0];
    
    const [totalEmployees] = await db.query(
      'SELECT COUNT(*) as count FROM users WHERE role = "employee"'
    );
    
    const [todayEntries] = await db.query(
      'SELECT COUNT(DISTINCT user_id) as count FROM attendance WHERE DATE(entry_time) = ?',
      [today]
    );
    
    return {
      totalEmployees: totalEmployees[0].count,
      todayEntries: todayEntries[0].count,
      missingEntries: totalEmployees[0].count - todayEntries[0].count
    };
  }
}

module.exports = Attendance;