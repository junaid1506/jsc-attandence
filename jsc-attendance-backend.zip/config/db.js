
const mysql = require('mysql2');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // or your password
  database: 'jsc-attendence'
});
module.exports = connection;
