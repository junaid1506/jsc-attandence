const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const db = require('../db');

const SECRET = 'your_jwt_secret';

// Middleware to verify token
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Unauthorized' });

  try {
    const decoded = jwt.verify(token, SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Invalid token' });
  }
};

// CREATE ATTENDANCE
router.post('/attendance', authenticate, (req, res) => {
  const { entry_time, exit_time } = req.body;
  const user_id = req.user.id;
  const date = new Date().toISOString().slice(0, 10);

  db.query(
    'INSERT INTO attendance (user_id, date, entry_time, exit_time) VALUES (?, ?, ?, ?)',
    [user_id, date, entry_time, exit_time],
    (err) => {
      if (err) return res.status(500).json({ message: 'Insert failed', error: err });
      res.json({ message: 'Attendance recorded successfully' });
    }
  );
});

// GET OWN ATTENDANCE
router.get('/attendance/me', authenticate, (req, res) => {
  const user_id = req.user.id;

  db.query('SELECT * FROM attendance WHERE user_id = ?', [user_id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Fetch failed' });
    res.json(results);
  });
});

// GET ALL ATTENDANCE (ADMIN)
router.get('/attendance', authenticate, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Access denied' });

  const { date, userId } = req.query;
  let sql = 'SELECT * FROM attendance WHERE 1=1';
  const params = [];

  if (date) {
    sql += ' AND date = ?';
    params.push(date);
  }
  if (userId) {
    sql += ' AND user_id = ?';
    params.push(userId);
  }

  db.query(sql, params, (err, results) => {
    if (err) return res.status(500).json({ message: 'Query failed', error: err });
    res.json(results);
  });
});

module.exports = router;
